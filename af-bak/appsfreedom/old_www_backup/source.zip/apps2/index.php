<!DOCTYPE html>
<html lang="en">
<head>
	<title>AppsFreedom Prototype App :: Apps</title>
	<link href="/plugins/custom_scroller/css/CustomScrollbar.css" rel="stylesheet">

	<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/head.php'); ?>
</head>
<body class="apps">
	<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/nav.php'); ?>

	<section class="hero bg-md-blue">
		<div class="jumbotron container text-center">
			<h1 class="headline">Procurement Apps</h1>
		</div>
		<div id="carousel-hero" class="carousel slide" data-interval="false" data-wrap="false">
			<div class="container">
				<div class="carousel-inner">
					<div class="item active">
						<div class="row">
							<div class="col-md-6 col-md-offset-1">
								<h3>Application Title Here</h3>
								<p><strong>Description:</strong> Display Accounts for a Sales Person as a list or on a Map based on sales person geo-location and Capability to Drill down to account related info like contacts, opportunities, activities, sales orders etc.</p>
								<p><strong>Integrates with:</strong> SAP</p>
							</div>
							<div class="col-md-5">
								<img src="/img/apps/slides/image_01.png" class="img-responsive center-block" alt="Model-Driven Platform">
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-7">
								<h3>Application Title Here</h3>
								<p><strong>Description:</strong> Display Accounts for a Sales Person as a list or on a Map based on sales person geo-location and Capability to Drill down to account related info like contacts, opportunities, activities, sales orders etc.</p>
								<p><strong>Integrates with:</strong> SAP</p>
							</div>
							<div class="col-md-5">
								<img src="/img/apps/slides/image_01.png" class="img-responsive center-block" alt="Model-Driven Platform">
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-7">
								<h3>Application Title Here</h3>
								<p><strong>Description:</strong> Display Accounts for a Sales Person as a list or on a Map based on sales person geo-location and Capability to Drill down to account related info like contacts, opportunities, activities, sales orders etc.</p>
								<p><strong>Integrates with:</strong> SAP</p>
							</div>
							<div class="col-md-5">
								<img src="/img/apps/slides/image_01.png" class="img-responsive center-block" alt="Model-Driven Platform">
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-7">
								<h3>Application Title Here</h3>
								<p><strong>Description:</strong> Display Accounts for a Sales Person as a list or on a Map based on sales person geo-location and Capability to Drill down to account related info like contacts, opportunities, activities, sales orders etc.</p>
								<p><strong>Integrates with:</strong> SAP</p>
							</div>
							<div class="col-md-5">
								<img src="/img/apps/slides/image_01.png" class="img-responsive center-block" alt="Model-Driven Platform">
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-7">
								<h3>Application Title Here</h3>
								<p><strong>Description:</strong> Display Accounts for a Sales Person as a list or on a Map based on sales person geo-location and Capability to Drill down to account related info like contacts, opportunities, activities, sales orders etc.</p>
								<p><strong>Integrates with:</strong> SAP</p>
							</div>
							<div class="col-md-5">
								<img src="/img/apps/slides/image_01.png" class="img-responsive center-block" alt="Model-Driven Platform">
							</div>
						</div>
					</div>
				</div>
				<div class="carousel-indicators-outer clearfix visible-lg">
					<div class="col-lg-1">
						<a href="#carousel-hero" class="carousel-controls" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
					</div>
					<div class="carousel-options col-lg-10">
						<ul class="carousel-indicators clearfix">
							<li data-target="#carousel-hero" data-slide-to="0" class="active">Application Title</li>
							<li data-target="#carousel-hero" data-slide-to="1">Application Title</li>
							<li data-target="#carousel-hero" data-slide-to="2">Application Title</li>
							<li data-target="#carousel-hero" data-slide-to="3">Application Title</li>
							<li data-target="#carousel-hero" data-slide-to="4">Application Title</li>
						</ul>
					</div>

					<div class="col-lg-1">
						<a href="#carousel-hero" class="carousel-controls" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
					</div>
				</div>
				<a class="left carousel-control" href="#carousel-hero" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left"></span>
				</a>
				<a class="right carousel-control" href="#carousel-hero" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right"></span>
				</a>
			</div>
		</div>
	</section>

	<section class="content bg-gray">
		<div class="container">
			<div class="col-md-6 app-library">
				<h1>Procurement Apps</h1>
				<div class="item bg-md-blue col-sm-3 hidden-xs">
					<img src="/img/home/procurement.png" class="center-block"/>
				</div>
				<p class="lede">To offer enterprises unprecedented time-to-value with comprehensive enterprise mobility solutions.</p>
				<p>Platform-as-a-Service. The appsFreedom platform turns citizen We’re an industry-leading provider of a Model-Driven Platform-as-a-Service. The appsFreedom platform turns citizen developers into super-heroes, firing out mobile and web apps fully integrated into IT’s core applications in days.</p>
				<p>Suit up with the appsFreedom platform, and turn your implementation time into days instead of months.</p>
				<p>Nulla vitae elit libero, a pharetra augue. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Curabitur blandit tempus porttitor.</p>
			</div>
			<div class="col-md-5 col-md-offset-1">
				<div class="col-sm-3 hidden-xs col-md-12">
					<img src="/img/apps/related_resources.png" class="img-responsive center-block" />
				</div>
			</div>
		</div>
	</section>

	<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer_cta.php'); ?>
	<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer.php'); ?>
	<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/scripts.php'); ?>

	<script src="/plugins/custom_scroller/js/CustomScrollbar.concat.min.js"></script>
	<script src="/js/custom.carousel.js"></script>
</body>
</html>