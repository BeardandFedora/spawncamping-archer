<!DOCTYPE html>
<html lang="en">
<head>
  <title>AppsFreedom Prototype App :: App Library</title>

  <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/head.php'); ?>
</head>
<body class="library">
  <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/nav.php'); ?>
  
  <section class="hero bg-dark-blue">
    <div class="container text-center">
      <div class="jumbotron">
        <div class="tour-header">
          <img src="/img/library/library-hero-header-lg.png" alt="" class="visible-md-block visible-lg-block center-block img-responsive" />
          <img src="/img/library/library-hero-header-sm.png" alt="" class="visible-xs-block visible-sm-block center-block" />
        </div>
        <h2 class="headline">Discover how appsFreedom lets you launch apps rapidly with our pre-integrated, fully customizable, ready to use app templates.</h2>
        <h1 class="headline">Business Function</h1>
      </div>
      <div class="app-library clearfix">
        <div class="col-md-2 col-md-offset-1 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>Sales</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>Procurement</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>Inventory</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-md-offset-1 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
        <div class="col-md-2 col-sm-6 col-xs-12">
          <a class="item bg-md-blue" href="#">
            <img src="/img/home/crm.png" class="center-block"/>
          </a>
          <p>CRM</p>
        </div>
      </div>
    </div>
  </section>

  <section class="content">
    <div class="container text-center">
      <div class="jumbotron">
        <div class="tour-header">
          <img src="/img/library/or.png" alt="" class="center-block" />
        </div>
        <h1 class="headline">Integrate Natively</h1>
      </div>
      <div class="app-library clearfix">
        <div class="col-md-3">
          <a class="item" href="#">
            <img src="/img/library/integrate/SAP.png" class="center-block"/>
          </a>
          <p>SAP</p>
        </div>
        <div class="col-md-3">
          <a class="item" href="#">
            <img src="/img/library/integrate/oracle.png" class="center-block"/>
          </a>
          <p>Oracle</p>
        </div>
        <div class="col-md-3">
          <a class="item" href="#">
            <img src="/img/library/integrate/salesforce.png" class="center-block"/>
          </a>
          <p>SalesForce</p>
        </div>
        <div class="col-md-3">
          <a class="item" href="#">
            <img src="/img/library/integrate/microsoft.png" class="center-block"/>
          </a>
          <p>Microsoft</p>
        </div>
      </div>
    </div>

    <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer_cta.php'); ?>
    <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer.php'); ?>
    <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/scripts.php'); ?>
  </body>
  </html>