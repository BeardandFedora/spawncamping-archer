<header>
  <nav class="navbar navbar-default navbar-main dark navbar-static-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="/">
          <img src="/img/logo-header-main.png" alt="">
        </a>
      </div>
    </div>
  </nav>
</header>