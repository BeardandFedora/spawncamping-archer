<section class="bg-light-blue footer-cta">
	<div class="container text-center">
		<a type="button" href="/testdrive" class="btn primary-button">Take A Test Drive <span class="btn-arrow"></a></button>
		<a href="/tour" class="btn btn-lg btn-link">Platform Tour <i class="glyphicon glyphicon-chevron-right"></i></a>
		<!-- <a href="#">Learning Center <i class="glyphicon glyphicon-chevron-right"></i></a> -->
	</div>
</section>