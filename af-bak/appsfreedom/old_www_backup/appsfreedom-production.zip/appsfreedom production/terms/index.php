<!DOCTYPE html>
<html lang="en">
<head>
  <title>AppsFreedom Prototype App :: Terms & Conditions</title>

  <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/head.php'); ?>
</head>
<body class="terms bg-gray">
  <?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/nav.php'); ?>
  
  <section class="hero">
    <div class="jumbotron container text-center">
      <h1 class="headline">Terms & Conditions</h1>
    </div>
  </section>
  <section class="content">
    <div class="container">
      <div class="col-lg-12">
        <h1>Tri-tip Tail Beef Ham</h1>
        <p>Capicola porchetta landjaeger corned beef, brisket bresaola meatball swine andouille. Shank ground round shankle, pastrami turkey hamburger spare ribs jerky meatball t-bone doner meatloaf bacon prosciutto corned beef.</p>
        <p>Tail t-bone jowl shank boudin. Kevin meatloaf capicola shankle rump tenderloin cow brisket pig turducken frankfurter fatback.</p>
        <p>Bacon ipsum dolor sit amet frankfurter short loin ham flank porchetta. Pork belly frankfurter chicken, swine hamburger spare ribs tri-tip sausage ham chuck landjaeger corned beef shoulder flank.</p>
        <p>Ball tip jerky frankfurter, ribeye drumstick strip steak bacon ground round pork loin tail cow spare ribs pork. Kielbasa leberkas venison boudin, tail pig turkey corned beef chicken porchetta pork loin tenderloin meatloaf chuck t-bone.</p>
      </div>
      <div class="col-lg-12">
        <h1>Hock Prosciutto Landjaeger</h1>
        <p>Bacon ipsum dolor sit amet frankfurter short loin ham flank porchetta. Pork belly frankfurter chicken, swine hamburger spare ribs tri-tip sausage ham chuck landjaeger corned beef shoulder flank.</p>
        <p>Ball tip jerky frankfurter, ribeye drumstick strip steak bacon.</p>
        <ol>
          <li>Ground round pork loin tail cow spare ribs.</li>
          <li>Kielbasa leberkas venison boudin, tail pig turkey corned beef chicken porchetta pork loin.</li>
        </ol>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
      <div class="col-lg-12">
        <h1>Boudin Jerky T-bone</h1>
        <p>Cow capicola tenderloin sausage. Pancetta ham hock shankle turducken leberkas meatloaf sirloin short loin swine beef ribs bacon shank jowl rump ham. Meatball drumstick chicken, flank pancetta shankle beef.</p>
        <p>Chuck doner leberkas tenderloin ham, porchetta sausage beef ribs t-bone meatloaf. Andouille turkey doner, meatloaf ground round pig turducken swine filet mignon ball tip pork loin pork belly landjaeger kielbasa. Filet mignon ham hock jerky corned beef bresaola.</p>
        <p>Shankle bresaola ham hock spare ribs swine, filet mignon beef ribs meatball chicken short loin tail doner shank ball tip biltong. </p>
      </div>
    </div>
  </div>
</section>

<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer_cta.php'); ?>
<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/footer.php'); ?>
<?php include( $_SERVER['DOCUMENT_ROOT'].'/includes/scripts.php'); ?>

<script src="/plugins/custom_scroller/js/CustomScrollbar.concat.min.js"></script>
<script src="/js/tour.js"></script>
</body>
</html>